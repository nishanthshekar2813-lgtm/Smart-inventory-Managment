# Inventory Manager

A full-stack Inventory Management System built with **React**, **TypeScript**, **Node.js**, **Express**, **Prisma ORM**, and **SQLite** (SQL Database).

![Inventory Manager Dashboard](https://i.imgur.com/your-screenshot.png)

## Features

- **User Authentication**: Secure login with username/password
- **Dashboard Overview**: Real-time inventory statistics
- **Inventory Management**: Add, edit, delete inventory items
- **Stock Alerts**: Visual indicators for low stock and out-of-stock items
- **Search & Filter**: Find items by name, category, or status
- **ABC Analysis**: Classify items by importance
- **Responsive Design**: Works on desktop and mobile devices

## Tech Stack

### Frontend
- **React 18** - UI library
- **TypeScript** - Type safety
- **Vite** - Build tool
- **Tailwind CSS** - Styling
- **shadcn/ui** - UI components
- **Lucide React** - Icons

### Backend
- **Node.js** - Runtime
- **Express.js** - Web framework
- **Prisma ORM** - Database ORM
- **SQLite** - SQL database
- **CORS** - Cross-origin requests

## Project Structure

```
inventory-manager/
├── backend/
│   ├── prisma/
│   │   └── schema.prisma    # Database schema
│   ├── server.js            # Express server
│   ├── package.json
│   └── .env                 # Environment variables
├── src/
│   ├── sections/
│   │   ├── LoginPage.tsx    # Login page
│   │   └── Dashboard.tsx    # Main dashboard
│   ├── hooks/
│   │   ├── useAuth.tsx      # Authentication hook
│   │   └── useInventory.tsx # Inventory API hook
│   ├── types/
│   │   └── index.ts         # TypeScript types
│   ├── components/ui/       # shadcn/ui components
│   ├── App.tsx
│   └── main.tsx
├── dist/                    # Production build
└── package.json
```

## Default Login Credentials

| Username | Password   | Role               |
|----------|------------|-------------------|
| admin    | admin123   | Administrator     |
| manager  | manager123 | Inventory Manager |

## Getting Started

### Prerequisites

- Node.js 18+ 
- npm or yarn

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd inventory-manager
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up the database (Optional - for Prisma/SQLite)**
   ```bash
   cd backend
   npx prisma migrate dev --name init
   npx prisma generate
   cd ..
   ```

4. **Start the development server**
   ```bash
   # Start both frontend and backend
   npm run dev
   
   # In another terminal, start the backend
   npm run server
   ```

5. **Or build and run production**
   ```bash
   npm start
   ```

6. **Open in browser**
   ```
   http://localhost:3001
   ```

## API Endpoints

### Authentication
- `POST /api/auth/login` - Login with credentials
- `POST /api/auth/logout` - Logout
- `GET /api/auth/me` - Get current user

### Inventory
- `GET /api/inventory` - Get all items (with filters)
- `GET /api/inventory/stats` - Get statistics
- `POST /api/inventory` - Create new item
- `PUT /api/inventory/:id` - Update item
- `DELETE /api/inventory/:id` - Delete item

### Categories
- `GET /api/categories` - Get all categories

## Database Schema (Prisma)

```prisma
model User {
  id        Int      @id @default(autoincrement())
  username  String   @unique
  password  String
  name      String
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
}

model InventoryItem {
  id          Int      @id @default(autoincrement())
  item        String
  category    String
  stock       Int
  reorderAt   Int
  unitCost    Float
  supplier    String
  abc         String
  status      String
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
}
```

## Environment Variables

Create a `.env` file in the `backend` directory:

```env
DATABASE_URL="file:./dev.db"
JWT_SECRET="your-super-secret-jwt-key"
PORT=3001
```

## Scripts

| Command           | Description                          |
|-------------------|--------------------------------------|
| `npm run dev`     | Start Vite dev server (frontend)     |
| `npm run build`   | Build for production                 |
| `npm run server`  | Start Express server (backend)       |
| `npm start`       | Build and start production server    |
| `npm run preview` | Preview production build             |

## License

MIT License
