# Inventory Manager Backend

This backend uses **Node.js**, **Express**, **Prisma ORM**, and **SQLite** (SQL database).

## Tech Stack

- **Runtime**: Node.js
- **Framework**: Express.js
- **ORM**: Prisma
- **Database**: SQLite (SQL)
- **Authentication**: JWT (JSON Web Tokens)

## Setup Instructions

### 1. Install Dependencies

```bash
npm install
```

### 2. Set up Prisma (Database)

```bash
# Initialize Prisma
npx prisma init

# Generate Prisma Client
npx prisma generate

# Run database migrations
npx prisma migrate dev --name init

# (Optional) Open Prisma Studio to view/edit data
npx prisma studio
```

### 3. Start the Server

```bash
# Development mode
npm run dev

# Production mode
npm start
```

The server will run on `http://localhost:3001`

## API Endpoints

### Authentication
- `POST /api/auth/login` - Login with username/password
- `POST /api/auth/logout` - Logout
- `GET /api/auth/me` - Get current user

### Inventory
- `GET /api/inventory` - Get all inventory items (with optional filters)
- `GET /api/inventory/stats` - Get inventory statistics
- `POST /api/inventory` - Create new item
- `PUT /api/inventory/:id` - Update item
- `DELETE /api/inventory/:id` - Delete item

### Categories
- `GET /api/categories` - Get all categories

## Default Login Credentials

- **Username**: `admin`
- **Password**: `admin123`

OR

- **Username**: `manager`
- **Password**: `manager123`

## Database Schema

The Prisma schema defines the following models:

- **User**: Stores user accounts with username/password
- **InventoryItem**: Stores inventory products with stock levels
- **Supplier**: Stores supplier information
- **Category**: Stores product categories
