const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());

// Serve static files from the React build
app.use(express.static(path.join(__dirname, '../dist')));

// In-memory database (simulating SQL/Prisma)
let users = [
  { id: 1, username: 'admin', password: 'admin123', name: 'Administrator' },
  { id: 2, username: 'manager', password: 'manager123', name: 'Inventory Manager' }
];

let inventory = [
  { id: 1, item: 'Wireless Headphones', category: 'Electronics', stock: 12, reorderAt: 30, unitCost: 2800, supplier: 'TechSource', abc: 'A', status: 'Low' },
  { id: 2, item: 'USB-C Cables (5-pack)', category: 'Electronics', stock: 180, reorderAt: 50, unitCost: 320, supplier: 'TechSource', abc: 'B', status: 'In stock' },
  { id: 3, item: 'Cotton T-Shirt (M)', category: 'Apparel', stock: 5, reorderAt: 40, unitCost: 450, supplier: 'FastGlobal', abc: 'B', status: 'Low' },
  { id: 4, item: 'Hand Sanitizer 500ml', category: 'FMCG', stock: 220, reorderAt: 100, unitCost: 95, supplier: 'MediSupply', abc: 'B', status: 'In stock' },
  { id: 5, item: 'AA Batteries (8-pack)', category: 'Electronics', stock: 0, reorderAt: 60, unitCost: 180, supplier: 'UniDist', abc: 'A', status: 'Out of stock' },
  { id: 6, item: 'Paracetamol 500mg', category: 'Pharma', stock: 60, reorderAt: 80, unitCost: 25, supplier: 'MediSupply', abc: 'C', status: 'Low' },
  { id: 7, item: 'LED Desk Lamp', category: 'Hardware', stock: 34, reorderAt: 20, unitCost: 1200, supplier: 'TechSource', abc: 'A', status: 'In stock' },
  { id: 8, item: 'Notebook A5', category: 'Stationery', stock: 500, reorderAt: 100, unitCost: 45, supplier: 'PaperMills', abc: 'C', status: 'In stock' },
  { id: 9, item: 'Wireless Mouse', category: 'Electronics', stock: 8, reorderAt: 25, unitCost: 850, supplier: 'TechSource', abc: 'A', status: 'Low' },
  { id: 10, item: 'Face Masks (50pcs)', category: 'FMCG', stock: 0, reorderAt: 30, unitCost: 150, supplier: 'MediSupply', abc: 'C', status: 'Out of stock' }
];

let sessions = {};

// Helper functions
const generateToken = () => Math.random().toString(36).substring(2) + Date.now().toString(36);

const calculateStats = () => {
  const totalSKUs = inventory.length;
  const inventoryValue = inventory.reduce((sum, item) => sum + (item.stock * item.unitCost), 0);
  const lowStock = inventory.filter(item => item.status === 'Low').length;
  const outOfStock = inventory.filter(item => item.status === 'Out of stock').length;
  const avgTurnover = 3.6;
  
  return {
    totalSKUs,
    inventoryValue,
    lowStock,
    outOfStock,
    avgTurnover
  };
};

// Authentication Routes
app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  
  const user = users.find(u => u.username === username && u.password === password);
  
  if (!user) {
    return res.status(401).json({ error: 'Invalid username or password' });
  }
  
  const token = generateToken();
  sessions[token] = { userId: user.id, username: user.username, name: user.name };
  
  res.json({
    token,
    user: {
      id: user.id,
      username: user.username,
      name: user.name
    }
  });
});

app.post('/api/auth/logout', (req, res) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (token && sessions[token]) {
    delete sessions[token];
  }
  res.json({ message: 'Logged out successfully' });
});

app.get('/api/auth/me', (req, res) => {
  const token = req.headers.authorization?.split(' ')[1];
  
  if (!token || !sessions[token]) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  
  res.json({ user: sessions[token] });
});

// Inventory Routes
app.get('/api/inventory', (req, res) => {
  const token = req.headers.authorization?.split(' ')[1];
  
  if (!token || !sessions[token]) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  
  const { search, category, status } = req.query;
  let filteredInventory = [...inventory];
  
  if (search) {
    filteredInventory = filteredInventory.filter(item => 
      item.item.toLowerCase().includes(search.toLowerCase()) ||
      item.category.toLowerCase().includes(search.toLowerCase()) ||
      item.supplier.toLowerCase().includes(search.toLowerCase())
    );
  }
  
  if (category && category !== 'All categories') {
    filteredInventory = filteredInventory.filter(item => item.category === category);
  }
  
  if (status && status !== 'All statuses') {
    filteredInventory = filteredInventory.filter(item => item.status === status);
  }
  
  res.json({
    items: filteredInventory,
    stats: calculateStats()
  });
});

app.get('/api/inventory/stats', (req, res) => {
  const token = req.headers.authorization?.split(' ')[1];
  
  if (!token || !sessions[token]) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  
  res.json(calculateStats());
});

app.post('/api/inventory', (req, res) => {
  const token = req.headers.authorization?.split(' ')[1];
  
  if (!token || !sessions[token]) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  
  const newItem = {
    id: Date.now(),
    ...req.body,
    status: req.body.stock === 0 ? 'Out of stock' : 
            req.body.stock <= req.body.reorderAt ? 'Low' : 'In stock'
  };
  
  inventory.push(newItem);
  res.status(201).json(newItem);
});

app.put('/api/inventory/:id', (req, res) => {
  const token = req.headers.authorization?.split(' ')[1];
  
  if (!token || !sessions[token]) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  
  const id = parseInt(req.params.id);
  const index = inventory.findIndex(item => item.id === id);
  
  if (index === -1) {
    return res.status(404).json({ error: 'Item not found' });
  }
  
  const updatedItem = {
    ...inventory[index],
    ...req.body,
    status: req.body.stock === 0 ? 'Out of stock' : 
            req.body.stock <= req.body.reorderAt ? 'Low' : 'In stock'
  };
  
  inventory[index] = updatedItem;
  res.json(updatedItem);
});

app.delete('/api/inventory/:id', (req, res) => {
  const token = req.headers.authorization?.split(' ')[1];
  
  if (!token || !sessions[token]) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  
  const id = parseInt(req.params.id);
  const index = inventory.findIndex(item => item.id === id);
  
  if (index === -1) {
    return res.status(404).json({ error: 'Item not found' });
  }
  
  inventory.splice(index, 1);
  res.json({ message: 'Item deleted successfully' });
});

// Categories
app.get('/api/categories', (req, res) => {
  const token = req.headers.authorization?.split(' ')[1];
  
  if (!token || !sessions[token]) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  
  const categories = [...new Set(inventory.map(item => item.category))];
  res.json(categories);
});

// Serve React app for all other routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../dist/index.html'));
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  console.log(`Open http://localhost:${PORT} in your browser`);
});
