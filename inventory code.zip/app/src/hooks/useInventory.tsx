import { useState, useCallback } from 'react';
import type { InventoryItem, InventoryStats } from '@/types';

const API_URL = 'http://localhost:3001/api';

// Demo mode - set to true for static deployment without backend
const DEMO_MODE = true;

// Demo inventory data
const DEMO_INVENTORY: InventoryItem[] = [
  { id: 1, item: 'Wireless Headphones', category: 'Electronics', stock: 12, reorderAt: 30, unitCost: 2800, supplier: 'TechSource', abc: 'A', status: 'Low' },
  { id: 2, item: 'USB-C Cables (5-pack)', category: 'Electronics', stock: 180, reorderAt: 50, unitCost: 320, supplier: 'TechSource', abc: 'B', status: 'In stock' },
  { id: 3, item: 'Cotton T-Shirt (M)', category: 'Apparel', stock: 5, reorderAt: 40, unitCost: 450, supplier: 'FastGlobal', abc: 'B', status: 'Low' },
  { id: 4, item: 'Hand Sanitizer 500ml', category: 'FMCG', stock: 220, reorderAt: 100, unitCost: 95, supplier: 'MediSupply', abc: 'B', status: 'In stock' },
  { id: 5, item: 'AA Batteries (8-pack)', category: 'Electronics', stock: 0, reorderAt: 60, unitCost: 180, supplier: 'UniDist', abc: 'A', status: 'Out of stock' },
  { id: 6, item: 'Paracetamol 500mg', category: 'Pharma', stock: 60, reorderAt: 80, unitCost: 25, supplier: 'MediSupply', abc: 'C', status: 'Low' },
  { id: 7, item: 'LED Desk Lamp', category: 'Hardware', stock: 34, reorderAt: 20, unitCost: 1200, supplier: 'TechSource', abc: 'A', status: 'In stock' },
  { id: 8, item: 'Notebook A5', category: 'Stationery', stock: 500, reorderAt: 100, unitCost: 45, supplier: 'PaperMills', abc: 'C', status: 'In stock' },
  { id: 9, item: 'Wireless Mouse', category: 'Electronics', stock: 8, reorderAt: 25, unitCost: 850, supplier: 'TechSource', abc: 'A', status: 'Low' },
  { id: 10, item: 'Face Masks (50pcs)', category: 'FMCG', stock: 0, reorderAt: 30, unitCost: 150, supplier: 'MediSupply', abc: 'C', status: 'Out of stock' }
];

const calculateStats = (items: InventoryItem[]): InventoryStats => {
  const totalSKUs = items.length;
  const inventoryValue = items.reduce((sum, item) => sum + (item.stock * item.unitCost), 0);
  const lowStock = items.filter(item => item.status === 'Low').length;
  const outOfStock = items.filter(item => item.status === 'Out of stock').length;
  const avgTurnover = 3.6;
  
  return {
    totalSKUs,
    inventoryValue,
    lowStock,
    outOfStock,
    avgTurnover
  };
};

export function useInventory() {
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [stats, setStats] = useState<InventoryStats | null>(null);
  const [categories, setCategories] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const getToken = () => localStorage.getItem('token');

  const fetchInventory = useCallback(async (filters?: { search?: string; category?: string; status?: string }) => {
    setIsLoading(true);
    setError(null);
    
    try {
      if (DEMO_MODE) {
        // Demo mode - filter mock data locally
        let filteredItems = [...DEMO_INVENTORY];
        
        if (filters?.search) {
          const searchLower = filters.search.toLowerCase();
          filteredItems = filteredItems.filter(item => 
            item.item.toLowerCase().includes(searchLower) ||
            item.category.toLowerCase().includes(searchLower) ||
            item.supplier.toLowerCase().includes(searchLower)
          );
        }
        
        if (filters?.category && filters.category !== 'All categories') {
          filteredItems = filteredItems.filter(item => item.category === filters.category);
        }
        
        if (filters?.status && filters.status !== 'All statuses') {
          filteredItems = filteredItems.filter(item => item.status === filters.status);
        }
        
        // Simulate network delay
        await new Promise(resolve => setTimeout(resolve, 300));
        
        setItems(filteredItems);
        setStats(calculateStats(DEMO_INVENTORY));
        
        // Extract unique categories
        const uniqueCategories = [...new Set(DEMO_INVENTORY.map(item => item.category))];
        setCategories(uniqueCategories);
      } else {
        // Real API call
        const params = new URLSearchParams();
        if (filters?.search) params.append('search', filters.search);
        if (filters?.category && filters.category !== 'All categories') params.append('category', filters.category);
        if (filters?.status && filters.status !== 'All statuses') params.append('status', filters.status);
        
        const response = await fetch(`${API_URL}/inventory?${params}`, {
          headers: {
            'Authorization': `Bearer ${getToken()}`
          }
        });
        
        if (!response.ok) {
          throw new Error('Failed to fetch inventory');
        }
        
        const data = await response.json();
        setItems(data.items);
        setStats(data.stats);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch inventory');
    } finally {
      setIsLoading(false);
    }
  }, []);

  const fetchCategories = useCallback(async () => {
    if (DEMO_MODE) {
      const uniqueCategories = [...new Set(DEMO_INVENTORY.map(item => item.category))];
      setCategories(uniqueCategories);
      return;
    }
    
    try {
      const response = await fetch(`${API_URL}/categories`, {
        headers: {
          'Authorization': `Bearer ${getToken()}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        setCategories(data);
      }
    } catch (err) {
      console.error('Failed to fetch categories:', err);
    }
  }, []);

  const createItem = async (item: Omit<InventoryItem, 'id' | 'status'>) => {
    if (DEMO_MODE) {
      const newItem: InventoryItem = {
        id: Date.now(),
        ...item,
        status: (item.stock === 0 ? 'Out of stock' : 
                item.stock <= item.reorderAt ? 'Low' : 'In stock') as 'In stock' | 'Low' | 'Out of stock'
      };
      DEMO_INVENTORY.push(newItem);
      setItems(prev => [...prev, newItem]);
      return newItem;
    }
    
    try {
      const response = await fetch(`${API_URL}/inventory`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${getToken()}`
        },
        body: JSON.stringify(item)
      });
      
      if (!response.ok) {
        throw new Error('Failed to create item');
      }
      
      const newItem = await response.json();
      setItems(prev => [...prev, newItem]);
      return newItem;
    } catch (err) {
      throw err;
    }
  };

  const updateItem = async (id: number, updates: Partial<InventoryItem>) => {
    if (DEMO_MODE) {
      const index = DEMO_INVENTORY.findIndex(item => item.id === id);
      if (index === -1) throw new Error('Item not found');
      
      const updatedItem: InventoryItem = {
        ...DEMO_INVENTORY[index],
        ...updates,
        status: (updates.stock === 0 ? 'Out of stock' : 
                updates.stock !== undefined && updates.stock <= (updates.reorderAt || DEMO_INVENTORY[index].reorderAt) ? 'Low' : 'In stock') as 'In stock' | 'Low' | 'Out of stock'
      };
      
      DEMO_INVENTORY[index] = updatedItem;
      setItems(prev => prev.map(item => item.id === id ? updatedItem : item));
      return updatedItem;
    }
    
    try {
      const response = await fetch(`${API_URL}/inventory/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${getToken()}`
        },
        body: JSON.stringify(updates)
      });
      
      if (!response.ok) {
        throw new Error('Failed to update item');
      }
      
      const updatedItem = await response.json();
      setItems(prev => prev.map(item => item.id === id ? updatedItem : item));
      return updatedItem;
    } catch (err) {
      throw err;
    }
  };

  const deleteItem = async (id: number) => {
    if (DEMO_MODE) {
      const index = DEMO_INVENTORY.findIndex(item => item.id === id);
      if (index === -1) throw new Error('Item not found');
      
      DEMO_INVENTORY.splice(index, 1);
      setItems(prev => prev.filter(item => item.id !== id));
      return;
    }
    
    try {
      const response = await fetch(`${API_URL}/inventory/${id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${getToken()}`
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to delete item');
      }
      
      setItems(prev => prev.filter(item => item.id !== id));
    } catch (err) {
      throw err;
    }
  };

  return {
    items,
    stats,
    categories,
    isLoading,
    error,
    fetchInventory,
    fetchCategories,
    createItem,
    updateItem,
    deleteItem
  };
}
