import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useInventory } from '@/hooks/useInventory';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import {
  Package,
  Search,
  Plus,
  Edit2,
  Trash2,
  LogOut,
  User
} from 'lucide-react';

export function Dashboard() {
  const { user, logout } = useAuth();
  const { items, stats, categories, isLoading, fetchInventory, deleteItem } = useInventory();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All categories');
  const [selectedStatus, setSelectedStatus] = useState('All statuses');
  const [activeTab, setActiveTab] = useState('inventory');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState<any>(null);

  useEffect(() => {
    fetchInventory({
      search: searchQuery,
      category: selectedCategory,
      status: selectedStatus
    });
  }, [searchQuery, selectedCategory, selectedStatus, activeTab]);

  const formatCurrency = (value: number) => {
    if (value >= 100000) {
      return `₹${(value / 100000).toFixed(1)}L`;
    }
    return `₹${value.toLocaleString()}`;
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'In stock':
        return (
          <Badge className="bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30 border-0">
            In stock
          </Badge>
        );
      case 'Low':
        return (
          <Badge className="bg-amber-500/20 text-amber-400 hover:bg-amber-500/30 border-0">
            Low
          </Badge>
        );
      case 'Out of stock':
        return (
          <Badge className="bg-red-500/20 text-red-400 hover:bg-red-500/30 border-0">
            Out of stock
          </Badge>
        );
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const getABCBadge = (abc: string) => {
    const colors: Record<string, string> = {
      'A': 'bg-blue-500/20 text-blue-400',
      'B': 'bg-purple-500/20 text-purple-400',
      'C': 'bg-slate-500/20 text-slate-400'
    };
    return (
      <span className={`inline-flex items-center justify-center w-6 h-6 rounded-full text-xs font-medium ${colors[abc] || colors['C']}`}>
        {abc}
      </span>
    );
  };

  const handleDelete = async () => {
    if (itemToDelete) {
      await deleteItem(itemToDelete.id);
      setIsDeleteDialogOpen(false);
      setItemToDelete(null);
    }
  };

  const filteredItems = items.filter(item => {
    if (activeTab === 'alerts') {
      return item.status === 'Low' || item.status === 'Out of stock';
    }
    return true;
  });

  const alertCount = (stats?.lowStock || 0) + (stats?.outOfStock || 0);

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Header */}
      <header className="border-b border-slate-800 bg-slate-900/50 backdrop-blur">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center">
                <Package className="w-5 h-5 text-emerald-400" />
              </div>
              <h1 className="text-xl font-bold text-white">Inventory Manager</h1>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 text-slate-400">
                <User className="w-4 h-4" />
                <span className="text-sm">{user?.name}</span>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={logout}
                className="text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
            <p className="text-slate-400 text-sm mb-1">Total SKUs</p>
            <p className="text-3xl font-bold text-white">{stats?.totalSKUs || 0}</p>
          </div>
          
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
            <p className="text-slate-400 text-sm mb-1">Inventory value</p>
            <p className="text-3xl font-bold text-white">{stats ? formatCurrency(stats.inventoryValue) : '₹0'}</p>
          </div>
          
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
            <p className="text-slate-400 text-sm mb-1">Low stock</p>
            <div className="flex items-baseline gap-2">
              <p className="text-3xl font-bold text-amber-400">{stats?.lowStock || 0}</p>
            </div>
            <p className="text-xs text-slate-500 mt-1">items need reorder</p>
          </div>
          
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
            <p className="text-slate-400 text-sm mb-1">Out of stock</p>
            <div className="flex items-baseline gap-2">
              <p className="text-3xl font-bold text-red-400">{stats?.outOfStock || 0}</p>
            </div>
            <p className="text-xs text-slate-500 mt-1">critical items</p>
          </div>
        </div>

        {/* Turnover Stats */}
        <div className="flex gap-8 mb-8">
          <div>
            <p className="text-slate-400 text-sm mb-1">Avg turnover</p>
            <p className="text-2xl font-bold text-emerald-400">{stats?.avgTurnover || 0}x</p>
            <p className="text-xs text-slate-500">sales/stock ratio</p>
          </div>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
          <TabsList className="bg-slate-900 border border-slate-800">
            <TabsTrigger 
              value="inventory" 
              className="data-[state=active]:bg-slate-800 data-[state=active]:text-white text-slate-400"
            >
              Inventory
            </TabsTrigger>
            <TabsTrigger 
              value="alerts"
              className="data-[state=active]:bg-slate-800 data-[state=active]:text-white text-slate-400"
            >
              Alerts ({alertCount})
            </TabsTrigger>
            <TabsTrigger 
              value="suppliers"
              className="data-[state=active]:bg-slate-800 data-[state=active]:text-white text-slate-400"
            >
              Suppliers
            </TabsTrigger>
            <TabsTrigger 
              value="analytics"
              className="data-[state=active]:bg-slate-800 data-[state=active]:text-white text-slate-400"
            >
              Analytics
            </TabsTrigger>
          </TabsList>
        </Tabs>

        {/* Actions Bar */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <Input
              placeholder="Search items..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-slate-900 border-slate-700 text-white placeholder:text-slate-500"
            />
          </div>
          
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="w-[180px] bg-slate-900 border-slate-700 text-white">
              <SelectValue placeholder="All categories" />
            </SelectTrigger>
            <SelectContent className="bg-slate-900 border-slate-700">
              <SelectItem value="All categories" className="text-white">All categories</SelectItem>
              {categories.map(cat => (
                <SelectItem key={cat} value={cat} className="text-white">{cat}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <Select value={selectedStatus} onValueChange={setSelectedStatus}>
            <SelectTrigger className="w-[180px] bg-slate-900 border-slate-700 text-white">
              <SelectValue placeholder="All statuses" />
            </SelectTrigger>
            <SelectContent className="bg-slate-900 border-slate-700">
              <SelectItem value="All statuses" className="text-white">All statuses</SelectItem>
              <SelectItem value="In stock" className="text-white">In stock</SelectItem>
              <SelectItem value="Low" className="text-white">Low</SelectItem>
              <SelectItem value="Out of stock" className="text-white">Out of stock</SelectItem>
            </SelectContent>
          </Select>
          
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-emerald-600 hover:bg-emerald-500 text-white">
                <Plus className="w-4 h-4 mr-2" />
                Add Item
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-slate-900 border-slate-700 text-white">
              <DialogHeader>
                <DialogTitle>Add New Item</DialogTitle>
                <DialogDescription className="text-slate-400">
                  Add a new item to your inventory.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label>Item Name</Label>
                  <Input className="bg-slate-800 border-slate-700 text-white" placeholder="Enter item name" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Category</Label>
                    <Input className="bg-slate-800 border-slate-700 text-white" placeholder="Category" />
                  </div>
                  <div className="space-y-2">
                    <Label>Supplier</Label>
                    <Input className="bg-slate-800 border-slate-700 text-white" placeholder="Supplier" />
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label>Stock</Label>
                    <Input type="number" className="bg-slate-800 border-slate-700 text-white" placeholder="0" />
                  </div>
                  <div className="space-y-2">
                    <Label>Reorder At</Label>
                    <Input type="number" className="bg-slate-800 border-slate-700 text-white" placeholder="0" />
                  </div>
                  <div className="space-y-2">
                    <Label>Unit Cost (₹)</Label>
                    <Input type="number" className="bg-slate-800 border-slate-700 text-white" placeholder="0" />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddDialogOpen(false)} className="border-slate-600 text-white hover:bg-slate-800">
                  Cancel
                </Button>
                <Button onClick={() => setIsAddDialogOpen(false)} className="bg-emerald-600 hover:bg-emerald-500 text-white">
                  Add Item
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        {/* Inventory Table */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="border-slate-800 hover:bg-transparent">
                <TableHead className="text-slate-400">Item</TableHead>
                <TableHead className="text-slate-400">Category</TableHead>
                <TableHead className="text-slate-400">Stock</TableHead>
                <TableHead className="text-slate-400">Reorder at</TableHead>
                <TableHead className="text-slate-400">Unit cost</TableHead>
                <TableHead className="text-slate-400">Supplier</TableHead>
                <TableHead className="text-slate-400">ABC</TableHead>
                <TableHead className="text-slate-400">Status</TableHead>
                <TableHead className="text-slate-400 text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={9} className="text-center py-8 text-slate-500">
                    Loading...
                  </TableCell>
                </TableRow>
              ) : filteredItems.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={9} className="text-center py-8 text-slate-500">
                    No items found
                  </TableCell>
                </TableRow>
              ) : (
                filteredItems.map((item) => (
                  <TableRow key={item.id} className="border-slate-800 hover:bg-slate-800/50">
                    <TableCell className="font-medium text-white">{item.item}</TableCell>
                    <TableCell className="text-slate-300">{item.category}</TableCell>
                    <TableCell className="text-white">{item.stock}</TableCell>
                    <TableCell className="text-slate-300">{item.reorderAt}</TableCell>
                    <TableCell className="text-white">₹{item.unitCost.toLocaleString()}</TableCell>
                    <TableCell className="text-slate-300">{item.supplier}</TableCell>
                    <TableCell>{getABCBadge(item.abc)}</TableCell>
                    <TableCell>{getStatusBadge(item.status)}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-slate-400 hover:text-emerald-400 hover:bg-emerald-500/10"
                        >
                          <Edit2 className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-slate-400 hover:text-red-400 hover:bg-red-500/10"
                          onClick={() => {
                            setItemToDelete(item);
                            setIsDeleteDialogOpen(true);
                          }}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </main>

      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="bg-slate-900 border-slate-700 text-white">
          <DialogHeader>
            <DialogTitle>Delete Item</DialogTitle>
            <DialogDescription className="text-slate-400">
              Are you sure you want to delete "{itemToDelete?.item}"? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)} className="border-slate-600 text-white hover:bg-slate-800">
              Cancel
            </Button>
            <Button onClick={handleDelete} className="bg-red-600 hover:bg-red-500 text-white">
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
