export interface User {
  id: number;
  username: string;
  name: string;
}

export interface InventoryItem {
  id: number;
  item: string;
  category: string;
  stock: number;
  reorderAt: number;
  unitCost: number;
  supplier: string;
  abc: string;
  status: 'In stock' | 'Low' | 'Out of stock';
}

export interface InventoryStats {
  totalSKUs: number;
  inventoryValue: number;
  lowStock: number;
  outOfStock: number;
  avgTurnover: number;
}

export interface LoginCredentials {
  username: string;
  password: string;
}

export interface AuthResponse {
  token: string;
  user: User;
}
